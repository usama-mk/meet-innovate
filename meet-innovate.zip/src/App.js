import './App.css';
import Router from './Components/Router/Router';
import About from './Pages/About/About';
import Home from './Pages/Home/Home';

function App() {
  return (
    <div className="App">
       {/* <Home/> */}
       {/* <About/> */}
       <Router/>
    </div>
  );
}

export default App;
